from airscript.system import R
from .module import ascript
import os

from .script.liaotu import lt
# from .script.soul import yh


op = ascript()

'''# 获取script目录下的文件名
ls = os.listdir(R(__file__).root("script"))
ls.remove('__pycache__')
msg = ''
for idx in range(len(ls)):
    msg += f'{idx+1}.{ls[idx][:-3]} '

mode = op.输入框('输入脚本序号', msg)
if mode == '1':
    lt()'''
lt()

print(n)