from airscript.action import touch    # 触摸
from airscript.action import key    # 按键
from ascript.android.system import Device    # 获取屏幕信息
from ascript.android.screen import FindImages    # 图色
from ascript.android.screen import Ocr    # 文字识别
from ascript.android.ui import Dialog   # 弹窗、输入框
from airscript.system import R  # 文件路径管理

from numpy import random
import cv2
import time
import os


class ascript():
    def __init__(self):
        self._info()
    
    def _info(self):
        display = Device.display()
        self.width = display.widthPixels if display.widthPixels<display.heightPixels else display.heightPixels
        self.height = display.widthPixels if display.widthPixels>display.heightPixels else display.heightPixels
        
    def 锁屏(self):
        key.lockscreen()
        
    def 点击(self, x:int, y:int):
        '''
        随机延迟点击
        '''
        touch.down(x, y)
        time.sleep(random.random())
        touch.up(x, y)

    def 模拟点击(self, x:int, y:int, loc:float):
        '''
        loc:均值,一般取正态分布的生成半径
        '''
        offset = random.normal(loc, int(loc**0.5), 2)
        X, Y = int(x+offset[0]), int(y+offset[1])
        touch.down (X, Y)
        time.sleep(random.random())
        touch.up (X, Y)

    def 滑动(self, x:int, y:int, dir:str, mode:str='right'):
        '''
        dir:滑动方向 up为上滑,down为下滑,left为左滑,right为右滑
        mode:默认右手模式(right),还有左手模式(left)
        '''
        offset = random.normal(64, 8, 2)
        if mode == 'left':
            if dir == 'up':
                x_end, y_end = x-offset[0], y-250-offset[1]
            elif dir == 'down':
                x_end, y_end = x-offset[0], y+250+offset[1]
            elif dir == 'left':
                x_end, y_end = x-300-offset[0], y+offset[1]
            elif dir == 'right':
                x_end, y_end = x+300-offset[0], y-offset[1]
        elif mode == 'right':
            if dir == 'up':
                x_end, y_end = x+offset[0], y-250-offset[1]
            elif dir == 'down':
                x_end, y_end = x+offset[0], y+250+offset[1]
            elif dir == 'left':
                x_end, y_end = x-300+offset[0], y+offset[1]
            elif dir == 'right':
                x_end, y_end = x+300+offset[0], y-offset[1]
        touch.down(x, y, 100)
        touch.move(x_end, y_end, 200)
        touch.up(x_end, y_end)

    def 图片缩放(self, img_path:list, img_dpi:tuple, save_path:list):
        '''
        img_path:图片相对路径(基于__init__所在目录)
        img_dpi:图片截取时的屏幕分辨率(高, 宽),可通过调用获取类的属性获取(self.height, self.width)
        save_path:图片保存路径(基于__init__所在目录),若该路径存在文件将不执行该图片的缩放
        '''
        ratio = self.width/img_dpi[1]
        for idx in range(len(img_path)):
            if os.path.exists(R(__file__).root(save_path[idx])):
                continue
            else:
                image = cv2.imread(R(__file__).root(img_path[idx]))
                height, width = image.shape[:2]
                resized_image = cv2.resize(image, (int(width*ratio), int(height*ratio)))
                cv2.imwrite(R(__file__).root(save_path[idx]), resized_image)
        
    def 找图(self, img_path:str, rect:list=[], sim:float=0.8):
        '''
        此函数返回可信度最高的图片中心坐标
        img_path:图片的相对路径(基于__init__所在目录)
        rect:接收四个参数,找图区域左上角坐标和右下角坐标,默认全屏
        sim:相似度
        '''
        if rect:
            res = FindImages.find(R(__file__).root(img_path), confidence=sim)
        else:
            res = FindImages.find(R(__file__).root(img_path), confidence=sim)
        if res:
            return (res['center_x'], res['center_y'])
        else:
            return None

    def 找图pro(self, img_path:str, rect:list=[], sim:float=0.8):
        '''
        此函数返回所有高于相似度的图片中心坐标
        img_path:图片的相对路径(基于__init__所在目录)
        rect:接收四个参数,找图区域左上角坐标和右下角坐标,默认全屏
        sim:相似度
        '''
        if rect:
            res = FindImages.find_all(R(__file__).root(img_path), rect, sim)
        else:
            res = FindImages.find_all(R(__file__).root(img_path), confidence=sim)
        if res:
            pos_list = [(i['center_x'], i['center_y']) for i in res]
            return pos_list
        else:
            return None

    def 正则匹配(self, pattern:str, rect:list=[], mode:str='google'):
        '''
        pattern:正则公式，匹配找字
        mode:默认google,可选paddlev2,paddlev3
            google:数字英文敏感，速度快
            paddle:中文敏感
                --v2:速度较v3快,精度反之
                --v3:速度较v2慢,精度反之
        rect:接收截取范围左上右下坐标
        '''
        if mode == 'google':
            if len(rect) == 4:
                result = Ocr.mlkitocr_v2(rect=rect, pattern=pattern)
            else:
                result = Ocr.mlkitocr_v2(pattern=pattern)
        elif mode == 'paddlev2':
            if len(rect) == 4:
                result = Ocr.paddleocr_v2(rect=rect, pattern=pattern)
            else:
                result = Ocr.paddleocr_v2(pattern=pattern)
        elif mode == 'paddlev3':
            if len(rect) == 4:
                result = Ocr.paddleocr_v3(rect=rect, pattern=pattern)
            else:
                result = Ocr.paddleocr_v3(pattern=pattern)
        
        if result:
            return [i.text for i in result]
        else:
            return None

    def 找字(self, target:str=None, rect:list=[], mode:str='paddlev2'):
        '''
        target:目标字
        mode:默认paddlev2,可选google,paddlev3
            google:数字英文敏感，速度快
            paddle:中文敏感
                --v2:速度较v3快,精度反之
                --v3:速度较v2慢,精度反之
        rect:接收截取范围左上右下坐标
        '''
        if mode == 'google':
            if len(rect) == 4:
                ots = Ocr.mlkitocr_v2(rect=rect)
            else:
                ots = Ocr.mlkitocr_v2()
        elif mode == 'paddlev2':
            if len(rect) == 4:
                ots = Ocr.paddleocr_v2(rect=rect)
            else:
                ots = Ocr.paddleocr_v2()
        elif mode == 'paddlev3':
            if len(rect) == 4:
                ots = Ocr.paddleocr_v3(rect=rect)
            else:
                ots = Ocr.paddleocr_v3()
        
        result = {}
        if ots:
            for ot in ots:
                result[ot.text] = (ot.center_x, ot.center_y)
        else:
            return None
        
        if target is None:
            return result
        elif target in result:
            return result[target]
        else:
            return None

    def 输入框(self, title:str, msg:str):
        '''
        title:设置标题
        msg:消息提示信息 默认:请输入信息
        # 以下参数原函数有,但未加入本函数,需要可添加参数
        value:输入框中的默认值
        hint:输入框中的提示值
        submit:设置确认按钮文本 默认:确认
        cancel:设置取消按钮文本 默认:取消
        '''
        result = Dialog.prompt(msg, title)
        return result

    def 弹窗(self, txt:str, dur:int=1000):
        '''
        txt:弹窗内容;
        dur:弹窗显示时间(毫秒),默认1s
        '''
        Dialog.toast(txt,dur,48|1,0,0)       
