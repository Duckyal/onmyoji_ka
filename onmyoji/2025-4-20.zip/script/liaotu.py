from ..module import ascript
import time
import random


class lt:
    def __init__(self):
        self.op = ascript()
        self.op.图片缩放(["res/img/Liaotu/main_page0.png", "res/img/Liaotu/no_challenge0.png", "res/img/Liaotu/start0.png", "res/img/Liaotu/victory0.png", "res/img/Liaotu/fail0.png"], 
                        (2460, 1080), 
                        ["res/img/Liaotu/main_page.png", "res/img/Liaotu/no_challenge.png", "res/img/Liaotu/start.png", "res/img/Liaotu/victory.png", "res/img/Liaotu/fail.png"])
        self.end = (int(self.op.height * 0.8),
                    int(self.op.width * 0.4),
                    int(self.op.width * 0.1))
        self._main()

    def _wait(self):  # 等待进入开始页
        while True:
            state = self.op.找图("res/img/Liaotu/main_page.png")
            if state is None:
                self.op.弹窗("未识别到寮突破界面")
            else:
                self.op.弹窗("请锁定阵容", 5000)
                time.sleep(5)
                break
        self.op.弹窗("开始运行寮突破")

    def _refresh(self):  # 滑动找挑战目标
        while True:
            if self.op.找图("res/img/Liaotu/no_challenge.png") is None:
                self.op.滑动(int(0.6 * self.op.height), int(0.6 * self.op.width), "up")
            else:
                break

    def _fight(self):
        while True:  # 进入战斗
            pos_list1 = self.op.找图pro("res/img/Liaotu/no_challenge.png", sim=0.8)
            pos_list2 = self.op.找图("res/img/Liaotu/start.png")
            pos_list3 = self.op.找图("res/img/Liaotu/main_page.png")
            if pos_list2 is not None:  # 点击挑战
                self.op.模拟点击(pos_list2[0], pos_list2[1]-25, 25)
                time.sleep(1)
            elif pos_list1 is not None:  # 选择结界
                pos1 = random.choice(pos_list1)
                self.op.模拟点击(pos1[0]-150, pos1[1], 25)
            elif pos_list3 is None:
                break
            elif pos_list1 is None:  # 下滑刷新结界
                self._refresh()
            time.sleep(1)
        while True:  # 退出战斗
            if self.op.找图("res/img/Liaotu/main_page.png"):
                break
            if self.op.找图("res/img/Liaotu/victory.png"):
                self.op.模拟点击(*self.end)
            elif self.op.找图("res/img/Liaotu/fail.png"):
                self.op.模拟点击(*self.end)
            else:
                time.sleep(5)

    def _main(self):  # 主逻辑
        self._wait()
        while True:
            result = self.op.正则匹配("[0-9]+.[0-9]{2}%", [0, 0, int(0.5 * self.op.height), self.op.width])
            if result:
                self.op.弹窗(f"进度:{result[0]}")
                if result[0] <= "90.00%":
                    result = self.op.正则匹配("\\S{5}[0-9]/6", [0, int(0.5 * self.op.width), int(0.5 * self.op.height), self.op.width], "paddlev2")
                    if result:
                        result = result[0][-3:]
                        self.op.弹窗(f'挑战次数{result}')
                        if result == "0/6":
                            self.op.弹窗("次数不足,休眠5min")
                            time.sleep(300)
                        else:
                            self._fight()
                else:
                    break
            else:
                time.sleep(5)
        self.op.弹窗("寮突破正常已结束")
        self.op.锁屏()
