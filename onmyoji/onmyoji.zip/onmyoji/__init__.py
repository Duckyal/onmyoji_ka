from airscript.screen import FindImages
from airscript.system import R
from .module import ascript

from .script.liaotu import lt
# from .script.soul import yh


op = ascript()

ls = ['寮突破']
msg = ';'.join(ls)
mode = op.输入框('输入模式启动脚本:', msg)
if mode == '寮突破':
    lt()

op.弹窗('脚本已结束')